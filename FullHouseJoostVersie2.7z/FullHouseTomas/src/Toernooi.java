public class Toernooi {

    //ATTRIBUTES
    private int ID;
    private String datum;
    private String locatie;
    private String begintijd;
    private String eindtijd;
    private String beschrijving;
    private String conditie;
    private int maxInschrijvingen;
    private int inleggeld;
    private String inschrijfdatum;

    Toernooi(int ID, String datum, String locatie, String begintijd, String eindtijd, String beschrijving, String conditie, int maxInschrijvingen, int inleggeld, String inschrijfdatum){
        this.ID = ID;
        this.datum = datum;
        this.locatie = locatie;
        this.begintijd = begintijd;
        this.eindtijd = eindtijd;
        this.beschrijving = beschrijving;
        this.conditie = conditie;
        this.maxInschrijvingen = maxInschrijvingen;
        this.inleggeld = inleggeld;
        this.inschrijfdatum = inschrijfdatum;
    }

    public int getID() {
        return ID;
    }

    public String getDatum() {
        return datum;
    }

    public String getLocatie() {
        return locatie;
    }

    public String getBegintijd() {
        return begintijd;
    }

    public String getEindtijd() {
        return eindtijd;
    }

    public String getBeschrijving() {
        return beschrijving;
    }

    public String getConditie() {
        return conditie;
    }

    public int getMaxInschrijvingen() {
        return maxInschrijvingen;
    }

    public int getInleggeld() {
        return inleggeld;
    }

    public String getInschrijfdatum() {
        return inschrijfdatum;
    }

    public String toString(){
        return ID + " " + datum + " " + locatie + " " + begintijd + " " + eindtijd + " " + beschrijving + " " + conditie + " " + maxInschrijvingen + " €" + inleggeld + " " + inschrijfdatum + " " + inschrijfdatum;
    }
}
