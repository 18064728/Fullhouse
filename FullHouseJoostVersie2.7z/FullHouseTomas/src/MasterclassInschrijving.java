public class MasterclassInschrijving {

    //todo moet nog gemaakt worden
}