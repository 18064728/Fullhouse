import javax.swing.*;
import java.awt.event.ActionListener;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.SQLException;

public class Main {

    public static void main(String[] args) {

        SwingUtilities.invokeLater(new Runnable() {
            @Override
            public void run() {
                JFrame frame1 = new Scherm();
            }

        });
    }
}

class ConnectionManager {
    static Connection getConnection() throws SQLException {
        if (connection == null)
            connection = DriverManager.getConnection("jdbc:mysql://meru.hhs.nl/18064728?useLegacyDatetimeCode=false&serverTimezone=Europe/Amsterdam",
                    "18064728", "aeph3vo3aV");
        return connection;
    }
    private static Connection connection;
}

class ListenerManager {
    static void deleteActionListeners(JButton button) {
        ActionListener[] ac = button.getActionListeners();
        for (ActionListener actionListener : ac) {
            button.removeActionListener(actionListener);
        }
    }
}
