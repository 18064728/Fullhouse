import javax.swing.*;
import java.awt.*;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;

public class Inlog extends JDialog {

    private static final int width = 250;
    private static final int height = 250;
    private static final String title = "FullHouse";

    private String username = "user";
    private String password = "root";

    public static void main(String[] args) {
        JDialog d = new Inlog();
        d.setSize(width, height);
        d.setTitle(title);
        d.setDefaultCloseOperation(DISPOSE_ON_CLOSE);
        d.setVisible(true);
    }

    private Inlog() {
        JPanel panel = new JPanel();
        panel.setLayout(new BoxLayout(panel, BoxLayout.PAGE_AXIS));

        JLabel usernameLbl = new JLabel("gebruikersnaam: ");
        JTextField usernameTxt = new JTextField();
        usernameTxt.setPreferredSize(new Dimension(50,25));

        JLabel passwordLbl = new JLabel("password: ");
        JPasswordField passwordField = new JPasswordField();
        passwordField.setPreferredSize(new Dimension(50,25));

        JButton inlog = new JButton("log in");

        panel.add(usernameLbl);
        panel.add(usernameTxt);
        panel.add(Box.createRigidArea(new Dimension(0,50)));
        panel.add(passwordLbl);
        panel.add(passwordField);
        panel.add(Box.createRigidArea(new Dimension(0,50)));
        panel.add(inlog);
        panel.add(Box.createRigidArea(new Dimension(100,0)));

        add(panel);

        class Listener implements ActionListener {
            private char[] cPassword;
            private String myPass = String.valueOf(passwordField.getPassword());

            public void actionPerformed(ActionEvent e) {
                if (usernameTxt.getText().equals(username) && myPass.equals(password)) {
                    new Scherm();
                    dispose();
                } else {
                    System.out.println("my pass is: " + myPass);
                    JOptionPane.showMessageDialog(inlog, "wrong username or password, please try again");
                }
            }

            //public String getPassword() {

            //}
        }

        ActionListener listener = new Listener();
        inlog.addActionListener(listener);

    }
}