import javax.swing.*;
import java.awt.event.ActionEvent;

public class Scherm extends JFrame {

    private static final String TITLE = "Full House";
    private static final int FRAME_WIDTH = 600;
    private static final int FRAME_HEIGHT = 400;

    private JLabel screenText;
    private JLabel toernooiScreenText;
    private JLabel gastenScreenText;
    private JLabel masterClassScreenText;

    private JButton toernooiButton;
    private JButton gastenButton;
    private JButton masterClassButton;

    private JButton toernooiToevoegen;
    private JButton toernooiVerwijderen;
    private JButton toernooiBewerken;
    private JButton toernooiTerug;

    private JButton gastenToevoegen;
    private JButton gastenVerwijderen;
    private JButton gastenBewerken;
    private JButton gastenTerug;

    private JButton masterClassToevoegen;
    private JButton masterClassVerwijderen;
    private JButton masterClassBewerken;
    private JButton masterClassTerug;

    private JPanel panel;

    Scherm(){
        JFrame scherm = new JFrame();
        scherm.setTitle(TITLE);
        scherm.setSize(FRAME_WIDTH, FRAME_HEIGHT);
        scherm.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        scherm.setVisible(true);

        try {
            UIManager.setLookAndFeel(UIManager.getSystemLookAndFeelClassName());
        } catch (Exception e) {
            e.printStackTrace();
        }

        panel = new JPanel();
        panel.setLayout(null);
        scherm.add(panel);

        //SCREEN 1
        screenText = new JLabel("Home screen voor Full House");
        screenText.setBounds(20, 20, 560, 180);
        panel.add(screenText);

        //Toernooi button
        toernooiButton = new JButton( new AbstractAction("Toernooi") {
            @Override
            public void actionPerformed( ActionEvent e ) {
                toernooiButton.setVisible(false);
                gastenButton.setVisible(false);
                masterClassButton.setVisible(false);
                screenText.setVisible(false);

                toernooiScreenText.setVisible(true);

                toernooiTerug.setVisible(true);
                toernooiToevoegen.setVisible(true);
                toernooiBewerken.setVisible(true);
            }
        });
        toernooiButton.setBounds(15, 250, 150, 50);
        panel.add(toernooiButton);

        //Gasten button
        gastenButton = new JButton( new AbstractAction("Gasten") {
            @Override
            public void actionPerformed( ActionEvent e ) {
                toernooiButton.setVisible(false);
                gastenButton.setVisible(false);
                masterClassButton.setVisible(false);
                screenText.setVisible(false);

                gastenScreenText.setVisible(true);

                gastenTerug.setVisible(true);
                gastenToevoegen.setVisible(true);
                gastenBewerken.setVisible(true);
            }
        });
        gastenButton.setBounds(215, 250, 150, 50);
        panel.add(gastenButton);

        //Master class button
        masterClassButton = new JButton( new AbstractAction("Master Class") {
            @Override
            public void actionPerformed( ActionEvent e ) {
                toernooiButton.setVisible(false);
                gastenButton.setVisible(false);
                masterClassButton.setVisible(false);
                screenText.setVisible(false);

                masterClassScreenText.setVisible(true);

                masterClassTerug.setVisible(true);
                masterClassToevoegen.setVisible(true);
                masterClassBewerken.setVisible(true);
            }
        });
        masterClassButton.setBounds(415, 250, 150, 50);
        panel.add(masterClassButton);

        //TOERNOOI SCREEN
        toernooiScreenText = new JLabel("Screen text voor toernooi");
        toernooiScreenText.setBounds(20, 20, 560, 180);
        toernooiScreenText.setVisible(false);
        panel.add(toernooiScreenText);

        toernooiTerug = new JButton( new AbstractAction("Terug") {
            @Override
            public void actionPerformed( ActionEvent e ) {
                toernooiTerug.setVisible(false);
                toernooiToevoegen.setVisible(false);
                toernooiBewerken.setVisible(false);

                toernooiScreenText.setVisible(false);

                toernooiButton.setVisible(true);
                gastenButton.setVisible(true);
                masterClassButton.setVisible(true);

                screenText.setVisible(true);
            }
        });
        toernooiTerug.setBounds(15, 200, 150, 50);
        toernooiTerug.setVisible(false);
        panel.add(toernooiTerug);

        toernooiToevoegen = new JButton( new AbstractAction("Toernooi toevoegen") {
            @Override
            public void actionPerformed( ActionEvent e ) {
                JDialog d = new ToernooiToevoegen();
            }
        });
        toernooiToevoegen.setBounds(175, 200, 150, 50);
        toernooiToevoegen.setVisible(false);
        panel.add(toernooiToevoegen);

        toernooiBewerken = new JButton( new AbstractAction("Toernooi bewerken en verwijderen") {
            @Override
            public void actionPerformed( ActionEvent e ) {
                JDialog d = new ToernooiControleren();
            }
        });
        toernooiBewerken.setBounds(15, 300, 310, 50);
        toernooiBewerken.setVisible(false);
        panel.add(toernooiBewerken);


        //GASTEN SCREEN
        gastenScreenText = new JLabel("Screen text voor gasten");
        gastenScreenText.setBounds(20, 20, 560, 180);
        gastenScreenText.setVisible(false);
        panel.add(gastenScreenText);

        gastenTerug = new JButton( new AbstractAction("Terug") {
            @Override
            public void actionPerformed( ActionEvent e ) {
                gastenTerug.setVisible(false);
                gastenToevoegen.setVisible(false);
                gastenBewerken.setVisible(false);

                gastenScreenText.setVisible(false);

                toernooiButton.setVisible(true);
                gastenButton.setVisible(true);
                masterClassButton.setVisible(true);

                screenText.setVisible(true);
            }
        });
        gastenTerug.setBounds(15, 200, 150, 50);
        gastenTerug.setVisible(false);
        panel.add(gastenTerug);

        gastenToevoegen = new JButton( new AbstractAction("Gasten toevoegen") {
            @Override
            public void actionPerformed( ActionEvent e ) {
                JDialog d = new GastToevoegen();
            }
        });
        gastenToevoegen.setBounds(175, 200, 150, 50);
        gastenToevoegen.setVisible(false);
        panel.add(gastenToevoegen);

        gastenBewerken = new JButton( new AbstractAction("Gasten bewerken en verwijderen") {
            @Override
            public void actionPerformed( ActionEvent e ) {
                JDialog d = new GastControleren();
            }
        });
        gastenBewerken.setBounds(15, 300, 310, 50);
        gastenBewerken.setVisible(false);
        panel.add(gastenBewerken);


        //MASTERCLASS SCREEN
        masterClassScreenText = new JLabel("Screen text voor masterclass");
        masterClassScreenText.setBounds(20, 20, 560, 180);
        masterClassScreenText.setVisible(false);
        panel.add(masterClassScreenText);

        masterClassTerug = new JButton( new AbstractAction("Terug") {
            @Override
            public void actionPerformed( ActionEvent e ) {
                masterClassTerug.setVisible(false);
                masterClassToevoegen.setVisible(false);
                masterClassBewerken.setVisible(false);

                masterClassScreenText.setVisible(false);

                toernooiButton.setVisible(true);
                gastenButton.setVisible(true);
                masterClassButton.setVisible(true);

                screenText.setVisible(true);
            }
        });
        masterClassTerug.setBounds(15, 200, 150, 50);
        masterClassTerug.setVisible(false);
        panel.add(masterClassTerug);

        masterClassToevoegen = new JButton( new AbstractAction("Masterclass toevoegen") {
            @Override
            public void actionPerformed( ActionEvent e ) {
                JDialog d = new MasterclassToevoegen();
            }
        });
        masterClassToevoegen.setBounds(175, 200, 150, 50);
        masterClassToevoegen.setVisible(false);
        panel.add(masterClassToevoegen);

        masterClassBewerken = new JButton( new AbstractAction("Masterclass bewerken en verwijderen") {
            @Override
            public void actionPerformed( ActionEvent e ) {

            }
        });
        masterClassBewerken.setBounds(15, 300, 310, 50);
        masterClassBewerken.setVisible(false);
        panel.add(masterClassBewerken);
     }
}