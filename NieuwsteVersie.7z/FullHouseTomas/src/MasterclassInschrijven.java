public class MasterclassInschrijven {

    public static void main(String[] args) {

    }
}