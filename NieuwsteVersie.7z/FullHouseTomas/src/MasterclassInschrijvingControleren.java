public class MasterclassInschrijvingControleren {

    public static void main(String[] args) {

    }
}