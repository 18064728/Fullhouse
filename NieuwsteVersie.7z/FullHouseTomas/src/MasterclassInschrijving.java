public class MasterclassInschrijving {

    int inschrijvingnr;
    int gastID;
    int masterclassID;
    String heeftBetaald;

    public MasterclassInschrijving(int inschrijvingnr, int gastID, int masterclassID, String heeftBetaald) {
        this.inschrijvingnr = inschrijvingnr;
        this.gastID = gastID;
        this.masterclassID = masterclassID;
        this.heeftBetaald = heeftBetaald;
    }

    public int getInschrijvingnr() {
        return inschrijvingnr;
    }

    public int getGastID() {
        return gastID;
    }

    public int getMasterclassID() {
        return masterclassID;
    }

    public String getHeeftBetaald() {
        return heeftBetaald;
    }

    public String toString() {
        return  "nr: " + inschrijvingnr + " gast: " + gastID + " toernooi: " + masterclassID + " heeft betaald: " + heeftBetaald;
    }
}