import javax.swing.*;
import java.sql.*;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;

/**
 * Medewerker krijgt een overzicht van alle gasten en heeft de mogelijkheid om ze te bewerken of te verwijderen
 */

public class BekendePokerspelerControleren extends JDialog {

    //JDIALOG
    private static final int width = 750;
    private static final int height = 500;
    private static final String title = "Bekende pokerspeler controleren";

    //ATTRIBUTES
    private String naam;


    private DefaultListModel<BekendePokerspeler> model;
    private JList<BekendePokerspeler> pokerspelers;

    private JButton bewerkBtn;
    private JButton terugBtn;
    private JButton verwijderBtn;

    BekendePokerspelerControleren()  {

        JPanel panel = new JPanel();
        panel.setLayout(null);

        try { //tries to make a connection with the database
            ResultSet rs = ConnectionManager.getConnection().createStatement().executeQuery("SELECT * FROM bekende_pokerspeler");

            model = new DefaultListModel<>();
            pokerspelers = new JList<>(model);
            panel.add(pokerspelers);
            JScrollPane sp = new JScrollPane(pokerspelers);
            sp.setBounds(125,25,500,400);
            panel.add(sp);

            while (rs.next()) {
                naam = rs.getString("naam");

                BekendePokerspeler bp = new BekendePokerspeler(naam);
                model.addElement(bp);
            }



        } catch (SQLException e) { //error message if there's no connection with the database
            System.out.println("er ging iets mis");
            e.printStackTrace();
        }

        this.setSize(width, height);
        this.setTitle(title);
        this.setDefaultCloseOperation(DISPOSE_ON_CLOSE);
        this.setVisible(true);

        if (model.isEmpty()) {
            JOptionPane.showMessageDialog(null, "er zijn nog geen bekende pokerspelers toegevoegd, voeg ze toe vie 'bekende pokerspeler toevoegen'");
        } else {

            bewerkBtn = new JButton("Bewerken");
            terugBtn = new JButton("Terug");
            verwijderBtn = new JButton("Verwijder");

            bewerkBtn.setBounds(0, 0, 100, 30);
            terugBtn.setBounds(0, 55, 100, 30);
            verwijderBtn.setBounds(0, 110, 100, 30);

            panel.add(bewerkBtn);
            panel.add(terugBtn);
            panel.add(verwijderBtn);

            ActionListener terug = new Terug();
            ActionListener verwijder = new Verwijder(pokerspelers);
            ActionListener bewerk = new Bewerk(pokerspelers);

            bewerkBtn.addActionListener(bewerk);
            terugBtn.addActionListener(terug);
            verwijderBtn.addActionListener(verwijder);

            this.add(panel);
        }
    }

    /**
     * gaat terug naar class 'Gasten'
     */
    class Terug implements ActionListener {
        @Override
        public void actionPerformed(ActionEvent e) {
            dispose();
        }
    }

    /**
     * opent formulier met gegevens van gekozen gast zodat die bewerkt kan worden
     */
    class Bewerk implements ActionListener {
        private JList<BekendePokerspeler> list;

        private Bewerk(JList<BekendePokerspeler> list) {
            this.list = list;
        }

        @Override
        public void actionPerformed(ActionEvent e) {
            try {
                if (list.isSelectionEmpty()) {
                    JOptionPane.showMessageDialog(null, "kies een bekende pokerspeler om te bewerken");
                }
                else {
                    //hetzelfde formulier als van GastToevoegen
                    class BekendePokerspelerBewerken extends BekendePokerspelerToevoegen {

                        private BekendePokerspelerBewerken() {
                            naamBekendTxt.setText(list.getSelectedValue().getNaam());
                        }

                        class Terug implements ActionListener {
                            public void actionPerformed(ActionEvent e) {
                                dispose();
                            }
                        }

                        class Wijzig implements ActionListener {
                            public void actionPerformed(ActionEvent e) {
                                naam =  naamBekendTxt.getText();

                                try {
                                    PreparedStatement ps = ConnectionManager.getConnection().prepareStatement("UPDATE bekende_pokerspeler SET naam = ? WHERE naam = ?;");
                                   // ps.setString(1,nieuweNaam);
                                    ps.setString(1, naam);

                                   // ps.executeUpdate();
                                    System.out.println("bekende pokerspeler is bijgewerkt");
                                } catch (Exception e1) {
                                    System.out.println("er ging iets fout");
                                    e1.printStackTrace();
                                }
                                JOptionPane.showMessageDialog(null,"bekende pokerspeler is gewijzigd");
                                dispose();
                            }
                        }
                    }
                    JDialog d = new BekendePokerspelerBewerken();
                    d.setSize(500, 500);
                    d.setTitle("Gast bewerken");
                    d.setResizable(false);
                    d.setVisible(true);
                    d.setDefaultCloseOperation(DISPOSE_ON_CLOSE);
                }
            } catch (Exception e1) {
                e1.printStackTrace();
            }
        }
    }

    /**
     * verwijderd gast van database
     */
    class Verwijder implements ActionListener {
        private JList<BekendePokerspeler> list;
        private Verwijder(JList<BekendePokerspeler> list) {
            this.list = list;
        }

        @Override
        public void actionPerformed(ActionEvent e) {
            try {
                if (list.isSelectionEmpty()) {
                    JOptionPane.showMessageDialog(null,"Kies een bekende pokerspeler om te verwijderen");
                }
                else {
                    String naam = list.getSelectedValue().getNaam();
                    PreparedStatement ps = ConnectionManager.getConnection().prepareStatement("DELETE FROM bekende_pokerspeler WHERE naam = ?");
                    ps.setString(1,naam);
                    ps.executeUpdate();
                    model.removeElement(list.getSelectedValue());
                }
            } catch (SQLException e1){
                e1.printStackTrace();
            }
        }
    }
}