import java.sql.*;

/**
 * Object Gast zoals die in de database hoort te staan
 */
public class Gast {

    private int ID;
    private String naam;
    private String geslacht;
    private String geboortedatum;
    private String adres;
    private String postcode;
    private String woonplaats;
    private String telefoonnummer;
    private String email;
    private int rating;

    Gast(int ID, String naam, String geslacht, String geboortedatum, String adres, String postcode, String woonplaats, String telefoonnummer, String email) {
        this.ID = ID;
        this.naam = naam;
        this.geslacht = geslacht;
        this.geboortedatum = geboortedatum;
        this.adres = adres;
        this.postcode = postcode;
        this.woonplaats = woonplaats;
        this.telefoonnummer = telefoonnummer;
        this.email = email;
    }

    int getID() {
        return ID;
    }

    String getNaam() {
        return naam;
    }

    String getGeslacht() {
        return geslacht;
    }

    String getGeboortedatum() {
        return geboortedatum;
    }

    String getAdres() {
        return adres;
    }

    String getPostcode() {
        return postcode;
    }

    String getWoonplaats() {
        return woonplaats;
    }

    String getTelefoonnummer() {
        return telefoonnummer;
    }

    String getEmail() {
        return email;
    }

    int getRating() {
        return rating;
    }

    public String toString() {
        return ID + " " + naam + " " + geslacht + " " + geboortedatum + " " + adres + " " + postcode + " " + woonplaats + " " + telefoonnummer + " " + email + " rating: " + rating;
    }
}