package fullhouse;

import javax.swing.*;
import javax.swing.table.DefaultTableModel;
import java.sql.*;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.util.ArrayList;

public class Gast_Controleren extends JDialog {

    //JDIALOG
    private static final int width = 1200;
    private static final int height = 550;
    private static final String title = "Gast Controleren";

    //DATABASE
    private Connection connection;
    private PreparedStatement ps;

    //ATTRIBUTES
    private int ID;
    private String naam;
    private String geslacht;
    private Date geboortedatum;
    private String adres;
    private String postcode;
    private String woonplaats;
    private String telefoonnummer;
    private String email;

    //TABLE
    private ArrayList<Gast> gasten;
    private int i = 0;

    //COMPONENTS
    private JTable table;
    private JButton terugBtn;

    public static void main(String[] args) {

        JDialog d = new Gast_Controleren();
        d.setSize(width, height);
        d.setTitle(title);
        d.setDefaultCloseOperation(DISPOSE_ON_CLOSE);
        d.setVisible(true);
    }

    public Gast_Controleren() {

        JPanel panel = new JPanel();
        panel.setLayout(null);

        try { //tries to make a connection with the database
            connection = DriverManager.getConnection(
                    "jdbc:mysql://meru.hhs.nl/18064728?useLegacyDatetimeCode=false&serverTimezone=Europe/Amsterdam","18064728", "aeph3vo3aV");

            ResultSet rs = connection.createStatement().executeQuery("SELECT * from gast");
            System.out.println("connected to database");

            String[] columnNames = { "ID", "naam", "geslacht", "geboortedatum", "adres", "postcode", "woonplaats", "telefoonnummer", "email"};
            String[][] data = {
                    { "001", "Piet", "man", "2000-01-01", "straat", "1234ab", "Den haag", "0612345678", "piet@email.com" },
                    { "002", "Kees", "man", "1999-12-31", "straat2", "5678cd", "Den haag", "0687654321", "kees@email.com" },
                    { "003", "Karen", "vrouw", "1989-03-15", "straat3", "2813dn", "Leiden", "0638593893", "karen@email.com" },
            };

            //JTable
            table = new JTable(data, columnNames);
            panel.add(table);
            JScrollPane j = new JScrollPane(table);
            j.setBounds(100,0,1000,500);
            panel.add(j);

            JButton bewerken = new JButton("bewerken");
            bewerken.setBounds(0,0,100,30);
            terugBtn = new JButton("terug");
            terugBtn.setBounds(0,50,100,30);

            panel.add(bewerken);
            panel.add(terugBtn);

            Gast gast;
            getGast();

            while (rs.next()) {
                /*ID = rs.getInt("ID");
                naam = rs.getString("naam");
                geslacht = rs.getString("geslacht");
                geboortedatum = rs.getDate("geboortedatum");
                adres = rs.getString("adres");
                postcode = rs.getString("postcode");
                woonplaats = rs.getString("woonplaats");
                telefoonnummer = rs.getString("telefoonnummer");
                email = rs.getString("email");
                System.out.println(resultSet.getInt("ID"));
                System.out.println(resultSet.getString("naam"));
                System.out.println(resultSet.getString("geslacht"));
                System.out.println(resultSet.getString("geboortedatum"));
                System.out.println(resultSet.getString("adres"));
                System.out.println(resultSet.getString("postcode"));
                System.out.println(resultSet.getString("woonplaats"));
                System.out.println(resultSet.getString("telefoonnummer"));
                System.out.println(resultSet.getString("email"));*/
                gast = new Gast(rs.getInt("ID"),rs.getString("naam"),rs.getString("geslacht"),rs.getDate("geboortedatum"),rs.getString("adres"),
                                rs.getString("postcode"),rs.getString("woonplaats"),rs.getString("telefoonnummer"),rs.getString("email"));
                gasten.add(i, gast);
                System.out.println(gasten);
                i++;
            }

        } catch (SQLException e) { //error message if there's no connection with the database
            System.out.println("can't connect to the database, please contact tech-support");
        }

        class Terug implements ActionListener {
            public void actionPerformed(ActionEvent e) {
                dispose();
                new Gasten();
            }
        }
        ActionListener terug = new Terug();
        terugBtn.addActionListener(terug);

        add(panel);
    }

    public void getGast() {
        gasten = new ArrayList<>();
        DefaultTableModel model = new DefaultTableModel();
        Object[] row = new Object[9];
        for (int j = 0; j < gasten.size(); j++) {
            row[0] = gasten.get(j).getID();
            row[1] = gasten.get(j).getNaam();
            row[2] = gasten.get(j).getGeslacht();
            row[3] = gasten.get(j).getGeboortedatum();
            row[4] = gasten.get(j).getAdres();
            row[5] = gasten.get(j).getPostcode();
            row[6] = gasten.get(j).getWoonplaats();
            row[7] = gasten.get(j).getTelefoonnummer();
            row[8] = gasten.get(j).getEmail();
            model.addRow(row);
        }
        
    }

}