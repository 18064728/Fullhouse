package fullhouse;

import java.sql.Time;
import java.util.Date;

/**
 * Object Toernooi zoals die in de database hoort te staan
 */
public class Toernooi {

    private int ID;
    private Date datum;
    private String locatie;
    private Time begintijd;
    private Time eindtijd;
    private String beschrijving;
    private String conditie;
    private int max_inschrijvingen;
    private int inleggeld;
    private Date inschrijfdatum;

    Toernooi(int ID, Date datum, String locatie, Time begintijd, Time eindtijd, String beschrijving, String conditie, int max_inschrijvingen, int inleggeld, Date inschrijfdatum ) {
        this.ID = ID;
        this.datum = datum;
        this.locatie = locatie;
        this.begintijd = begintijd;
        this.eindtijd = eindtijd;
        this.beschrijving = beschrijving;
        this.conditie = conditie;
        this.max_inschrijvingen = max_inschrijvingen;
        this.inleggeld = inleggeld;
        this.inschrijfdatum = inschrijfdatum;
    }

    public int getID() {
        return ID;
    }

    public Date getDatum() {
        return datum;
    }

    public String getLocatie() {
        return locatie;
    }

    public Time getBegintijd() {
        return begintijd;
    }

    public Time getEindtijd() {
        return eindtijd;
    }

    public String getBeschrijving() {
        return beschrijving;
    }

    public String getConditie() {
        return conditie;
    }

    public int getMax_inschrijvingen() {
        return max_inschrijvingen;
    }

    public int getInleggeld() {
        return inleggeld;
    }

    public Date getInschrijfdatum() {
        return inschrijfdatum;
    }

    public String toString() {
        return ID + " " + datum + " " + locatie + " " + begintijd + " " + eindtijd + " " + beschrijving + " " + conditie + " " + max_inschrijvingen + " " + inleggeld + inschrijfdatum;
    }

    public static void main(String[] args) {

    }
}