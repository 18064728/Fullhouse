import javax.swing.*;
import java.awt.event.ActionEvent;
import java.util.Arrays;
/**
 * Medewerker krijgt een scherm te zien waarin ingelogd moet worden
 */
class Inlog extends JDialog {

    private static final int WIDTH = 250;
    private static final int HEIGHT = 250;
    private static final String TITLE = "FullHouse";

    private JPanel panel;

    private JLabel usernameLbl;
    private JLabel passwordLbl;

    private JTextField usernameTxt;
    private JPasswordField passwordField;

    private JButton inlog;

    private String username = "medewerker1";
    private char[] password = new char[] {'p', 'a', 's', 's', 'w', 'o', 'r', 'd'};

    Inlog() {
        this.setSize(WIDTH, HEIGHT);
        this.setTitle(TITLE);
        this.setDefaultCloseOperation(DISPOSE_ON_CLOSE);
        this.setVisible(true);

        panel = new JPanel();
        panel.setLayout(null);
        this.add(panel);

        usernameLbl = new JLabel("Gebruikersnaam: ");
        usernameLbl.setBounds(10, 10, 150, 25);

        usernameTxt = new JTextField();
        usernameTxt.setBounds(10, 40, 150, 25);

        passwordLbl = new JLabel("Watchwoord: ");
        passwordLbl.setBounds(10, 80, 150, 25);

        passwordField = new JPasswordField();
        passwordField.setBounds(10, 110, 150, 25);

        inlog = new JButton(new AbstractAction("Log in") {
            @Override
            public void actionPerformed(ActionEvent e) {
                char[] currentPassword = passwordField.getPassword();
                char[] correctPassword = password;

                if(Arrays.equals(currentPassword, correctPassword) && usernameTxt.getText().equals(username)){
                    JFrame scherm = new Scherm();
                    dispose();
                }
                else if(Arrays.equals(currentPassword, correctPassword)){
                    JOptionPane.showMessageDialog(inlog,"De username klopt niet.");
                }
                else if(usernameTxt.getText().equals(username)){
                    JOptionPane.showMessageDialog(inlog, "Het wachtwoord klopt niet");
                }
                else{
                    JOptionPane.showMessageDialog(inlog, "Beide de username en het wachtwoord kloppen niet");
                }
            }
        });
        inlog.setBounds(10, 180, 150, 25);

        panel.add(usernameLbl);
        panel.add(usernameTxt);
        panel.add(passwordLbl);
        panel.add(passwordField);
        panel.add(inlog);
    }
}