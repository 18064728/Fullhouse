/**
 * De attributen die nodig zijn voor een inschrijving in de Masterclass
 */

public class MasterclassInschrijving {

    int inschrijvingnr;
    int gastID;
    int masterclassID;
    String heeftBetaald;

    MasterclassInschrijving(int inschrijvingnr, int gastID, int masterclassID, String heeftBetaald) {
        this.inschrijvingnr = inschrijvingnr;
        this.gastID = gastID;
        this.masterclassID = masterclassID;
        this.heeftBetaald = heeftBetaald;
    }

    int getInschrijvingnr() {
        return inschrijvingnr;
    }

    public int getGastID() {
        return gastID;
    }

    public int getMasterclassID() {
        return masterclassID;
    }

    public String getHeeftBetaald() {
        return heeftBetaald;
    }

    public String toString() {
        return  "INSCHRIJVING NR: " + inschrijvingnr + " GAST ID: " + gastID + " MASTERCLASS: " + masterclassID + " HEEFT BETAALD: " + heeftBetaald;
    }
}