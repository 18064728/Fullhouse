/**
 * Object Toernooi zoals deze in de Database hoort te staan
 */

public class Toernooi {

    //ATTRIBUTES
    private int ID;
    private String datum;
    private String locatie;
    private String begintijd;
    private String eindtijd;
    private String beschrijving;
    private String conditie;
    private int maxInschrijvingen;
    private int inleggeld;
    private String inschrijfdatum;
    //private int totaalInleg;
    //private int aantalRondes;

    Toernooi(int ID, String datum, String locatie, String begintijd, String eindtijd, String beschrijving, String conditie, int maxInschrijvingen, int inleggeld, String inschrijfdatum){
        this.ID = ID;
        this.datum = datum;
        this.locatie = locatie;
        this.begintijd = begintijd;
        this.eindtijd = eindtijd;
        this.beschrijving = beschrijving;
        this.conditie = conditie;
        this.maxInschrijvingen = maxInschrijvingen;
        this.inleggeld = inleggeld;
        this.inschrijfdatum = inschrijfdatum;
        //this.totaalInleg = totaalInleg;
        //this.aantalRondes = aantalRondes;
    }

    public int getID() {
        return ID;
    }

    public String getDatum() {
        return datum;
    }

    public String getLocatie() {
        return locatie;
    }

    public String getBegintijd() {
        return begintijd;
    }

    public String getEindtijd() {
        return eindtijd;
    }

    String getBeschrijving() {
        return beschrijving;
    }

    String getConditie() {
        return conditie;
    }

    int getMaxInschrijvingen() {
        return maxInschrijvingen;
    }

    int getInleggeld() {
        return inleggeld;
    }

    String getInschrijfdatum() {
        return inschrijfdatum;
    }

//    int getTotaalInleg(){
//        return totaalInleg;
//    }

//    int getAantalRondes(){
//        return aantalRondes;
//    }

    public String toString(){
        return "ID: " + ID + " DATUM: " + datum + " LOCATIE: " + locatie + " BEGINTIJD: " + begintijd + " EINDTIJD: " + eindtijd + " BESCHRIJVING: " + beschrijving + " CONDITIE: " + conditie + " MAX INSCHRIJVINGEN: " + maxInschrijvingen + " INLEG €" + inleggeld + " INSCHRIJFDATUM: " + inschrijfdatum;
    }
}
