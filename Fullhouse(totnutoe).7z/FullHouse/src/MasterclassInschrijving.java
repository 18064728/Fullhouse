public class MasterclassInschrijving {

    public static void main(String[] args) {

    }
}