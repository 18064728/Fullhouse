import javax.swing.*;
import java.awt.event.ActionEvent;

class Scherm extends JFrame {

    private static final String TITLE = "Full House";
    private static final int FRAME_WIDTH = 600;
    private static final int FRAME_HEIGHT = 400;

    private JLabel screenText;
    private JLabel toernooiScreenText;
    private JLabel gastenScreenText;
    private JLabel masterClassScreenText;
    private JLabel inschrijvingScreenText;

    private JButton toernooiButton;
    private JButton gastenButton;
    private JButton masterClassButton;
    private JButton inschrijvingButton;

    private JButton toernooiToevoegen;
    private JButton toernooiControleren;
    private JButton toernooiTerug;

    private JButton gastenToevoegen;
    private JButton gastenControleren;
    private JButton gastenTerug;
    private JButton inschrijvingButtonTerug;

    private JButton masterClassToevoegen;
    private JButton masterClassBewerken;
    private JButton masterClassTerug;

    private JButton voorToernooi;
    private JButton voorMasterclass;

    Scherm(){
        JFrame scherm = new JFrame();
        scherm.setTitle(TITLE);
        scherm.setSize(FRAME_WIDTH, FRAME_HEIGHT);
        scherm.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        scherm.setVisible(true);

        try {
            UIManager.setLookAndFeel(UIManager.getSystemLookAndFeelClassName());
        } catch (Exception e) {
            e.printStackTrace();
        }

        JPanel panel = new JPanel();
        panel.setLayout(null);
        scherm.add(panel);

        //SCREEN 1
        screenText = new JLabel("Home screen voor Full House");
        screenText.setBounds(20, 20, 560, 180);
        panel.add(screenText);

        //Toernooi button
        toernooiButton = new JButton( new AbstractAction("Toernooi") {
            @Override
            public void actionPerformed( ActionEvent e ) {
                toernooiButton.setVisible(false);
                gastenButton.setVisible(false);
                masterClassButton.setVisible(false);
                inschrijvingButton.setVisible(false);
                screenText.setVisible(false);

                toernooiScreenText.setVisible(true);

                toernooiTerug.setVisible(true);
                toernooiToevoegen.setVisible(true);
                toernooiControleren.setVisible(true);

            }
        });
        toernooiButton.setBounds(15, 250, 150, 50);
        panel.add(toernooiButton);

        //Gasten button
        gastenButton = new JButton( new AbstractAction("Gasten") {
            @Override
            public void actionPerformed( ActionEvent e ) {
                toernooiButton.setVisible(false);
                gastenButton.setVisible(false);
                masterClassButton.setVisible(false);
                inschrijvingButton.setVisible(false);
                screenText.setVisible(false);

                gastenScreenText.setVisible(true);

                gastenTerug.setVisible(true);
                gastenToevoegen.setVisible(true);
                gastenControleren.setVisible(true);
            }
        });
        gastenButton.setBounds(300, 250, 150, 50);
        panel.add(gastenButton);

        //Master class button
        masterClassButton = new JButton( new AbstractAction("Master Class") {
            @Override
            public void actionPerformed( ActionEvent e ) {
                toernooiButton.setVisible(false);
                gastenButton.setVisible(false);
                masterClassButton.setVisible(false);
                inschrijvingButton.setVisible(false);
                screenText.setVisible(false);

                masterClassScreenText.setVisible(true);

                masterClassTerug.setVisible(true);
                masterClassToevoegen.setVisible(true);
                masterClassBewerken.setVisible(true);
            }
        });
        masterClassButton.setBounds(15, 175, 150, 50);
        panel.add(masterClassButton);

        //inschrijvingButton class button
        inschrijvingButton = new JButton(new AbstractAction("inschrijven") {
            @Override
            public void actionPerformed(ActionEvent e) {
                toernooiButton.setVisible(false);
                gastenButton.setVisible(false);
                masterClassButton.setVisible(false);
                inschrijvingButton.setVisible(false);
                screenText.setVisible(false);

                inschrijvingScreenText.setVisible(true);
                voorToernooi.setVisible(true);
                voorMasterclass.setVisible(true);
                inschrijvingButtonTerug.setVisible(true);
            }
        });
        inschrijvingButton.setBounds(300,175,150,50);
        panel.add(inschrijvingButton);

        //TOERNOOI SCREEN
        toernooiScreenText = new JLabel("Screen text voor toernooi");
        toernooiScreenText.setBounds(20, 20, 560, 180);
        toernooiScreenText.setVisible(false);
        panel.add(toernooiScreenText);

        toernooiTerug = new JButton( new AbstractAction("Terug") {
            @Override
            public void actionPerformed( ActionEvent e ) {
                toernooiTerug.setVisible(false);
                toernooiToevoegen.setVisible(false);
                toernooiControleren.setVisible(false);

                toernooiScreenText.setVisible(false);

                toernooiButton.setVisible(true);
                gastenButton.setVisible(true);
                masterClassButton.setVisible(true);
                inschrijvingButton.setVisible(true);

                screenText.setVisible(true);
            }
        });
        toernooiTerug.setBounds(15, 200, 150, 50);
        toernooiTerug.setVisible(false);
        panel.add(toernooiTerug);

        toernooiToevoegen = new JButton( new AbstractAction("Toernooi toevoegen") {
            @Override
            public void actionPerformed( ActionEvent e ) {
                JDialog d = new ToernooiToevoegen();
                d.setSize(500,550);
                d.setVisible(true);
            }
        });
        toernooiToevoegen.setBounds(420, 200, 150, 50);
        toernooiToevoegen.setVisible(false);
        panel.add(toernooiToevoegen);

        toernooiControleren = new JButton( new AbstractAction("Toernooi controleren") {
            @Override
            public void actionPerformed( ActionEvent e ) {
                JDialog d = new ToernooiControleren();
                d.setSize(750,500);
                d.setVisible(true);
            }
        });
        toernooiControleren.setBounds(15, 300, 150, 50);
        toernooiControleren.setVisible(false);
        panel.add(toernooiControleren);

        //GASTEN SCREEN
        gastenScreenText = new JLabel("Screen text voor gasten");
        gastenScreenText.setBounds(20, 20, 560, 180);
        gastenScreenText.setVisible(false);
        panel.add(gastenScreenText);

        gastenTerug = new JButton( new AbstractAction("Terug") {
            @Override
            public void actionPerformed( ActionEvent e ) {
                gastenTerug.setVisible(false);
                gastenToevoegen.setVisible(false);
                gastenControleren.setVisible(false);

                gastenScreenText.setVisible(false);

                toernooiButton.setVisible(true);
                gastenButton.setVisible(true);
                masterClassButton.setVisible(true);
                inschrijvingButton.setVisible(true);

                screenText.setVisible(true);
            }
        });
        gastenTerug.setBounds(15, 200, 150, 50);
        gastenTerug.setVisible(false);
        panel.add(gastenTerug);

        gastenToevoegen = new JButton( new AbstractAction("Gasten toevoegen") {
            @Override
            public void actionPerformed( ActionEvent e ) {
                JDialog d = new GastToevoegen();
                d.setSize(500,500);
                d.setVisible(true);
            }
        });
        gastenToevoegen.setBounds(420, 200, 150, 50);
        gastenToevoegen.setVisible(false);
        panel.add(gastenToevoegen);

        gastenControleren = new JButton( new AbstractAction("Gasten controleren") {
            @Override
            public void actionPerformed( ActionEvent e ) {
                JDialog d = new GastControleren();
                d.setSize(750,500);
                d.setVisible(true);
            }
        });

        gastenControleren.setBounds(15, 300, 150, 50);
        gastenControleren.setVisible(false);
        panel.add(gastenControleren);

        //MASTERCLASS SCREEN
        masterClassScreenText = new JLabel("Screen text voor masterclass");
        masterClassScreenText.setBounds(20, 20, 560, 180);
        masterClassScreenText.setVisible(false);
        panel.add(masterClassScreenText);

        masterClassTerug = new JButton( new AbstractAction("Terug") {
            @Override
            public void actionPerformed( ActionEvent e ) {
                masterClassTerug.setVisible(false);
                masterClassToevoegen.setVisible(false);
                masterClassBewerken.setVisible(false);

                masterClassScreenText.setVisible(false);

                toernooiButton.setVisible(true);
                gastenButton.setVisible(true);
                masterClassButton.setVisible(true);
                inschrijvingButton.setVisible(true);

                screenText.setVisible(true);
            }
        });
        masterClassTerug.setBounds(15, 200, 150, 50);
        masterClassTerug.setVisible(false);
        panel.add(masterClassTerug);

        masterClassToevoegen = new JButton( new AbstractAction("Masterclass toevoegen") {
            @Override
            public void actionPerformed( ActionEvent e ) {
                JDialog d = new MasterclassToevoegen();
                d.setSize(500,550);
                d.setVisible(true);
            }
        });
        masterClassToevoegen.setBounds(420, 200, 150, 50);
        masterClassToevoegen.setVisible(false);
        panel.add(masterClassToevoegen);

        masterClassBewerken = new JButton( new AbstractAction("Masterclass controleren") {
            @Override
            public void actionPerformed( ActionEvent e ) {
                // JDialog d = new Masterclass_controleren();
                // d.setSize(500,550);
                // d.setVisible(true);
            }
        });
        masterClassBewerken.setBounds(15, 300, 150, 50);
        masterClassBewerken.setVisible(false);
        panel.add(masterClassBewerken);


        //inschrijvingButton SCREEN
        inschrijvingScreenText = new JLabel("Screen text voor toernooi");
        inschrijvingScreenText.setBounds(20, 20, 100, 100);
        inschrijvingScreenText.setVisible(false);
        panel.add(toernooiScreenText);

        inschrijvingButtonTerug = new JButton( new AbstractAction("Terug") {
            @Override
            public void actionPerformed( ActionEvent e ) {
                inschrijvingButtonTerug.setVisible(false);
                voorToernooi.setVisible(false);
                voorMasterclass.setVisible(false);

                masterClassScreenText.setVisible(false);

                toernooiButton.setVisible(true);
                gastenButton.setVisible(true);
                masterClassButton.setVisible(true);
                inschrijvingButton.setVisible(true);

                screenText.setVisible(true);
            }
        });
        inschrijvingButtonTerug.setBounds(400, 200, 150, 50);
        inschrijvingButtonTerug.setVisible(false);
        panel.add(inschrijvingButtonTerug);

        voorToernooi = new JButton( new AbstractAction("voor toernooi") {
            @Override
            public void actionPerformed( ActionEvent e ) {
                gastenTerug.setVisible(false);
                gastenToevoegen.setVisible(false);
                gastenControleren.setVisible(false);

                gastenScreenText.setVisible(false);

                new ToernooiInschrijven();
            }
        });
        voorToernooi.setBounds(15, 200, 150, 50);
        voorToernooi.setVisible(false);
        panel.add(voorToernooi);

        voorMasterclass = new JButton( new AbstractAction("voor masterclass") {
            @Override
            public void actionPerformed( ActionEvent e ) {
                gastenTerug.setVisible(false);
                gastenToevoegen.setVisible(false);
                gastenControleren.setVisible(false);

                gastenScreenText.setVisible(false);

                new MasterclassInschrijving();
            }
        });
        voorMasterclass.setBounds(210, 200, 150, 50);
        voorMasterclass.setVisible(false);
        panel.add(voorMasterclass);
    }
}