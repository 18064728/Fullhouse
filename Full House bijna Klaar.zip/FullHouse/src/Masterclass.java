/**
 * Masterclass zoals deze in de Database hoort te staan
 */

public class Masterclass {

    //ATTRIBUTES
    private int ID;
    private String datum;
    private String locatie;
    private String begintijd;
    private String eindtijd;

    private int kosten;
    private int minRating;
    private String bekendePokerspeler;

    Masterclass(int ID, String datum, String locatie, String begintijd, String eindtijd, int kosten, int minRating, String bekendePokerspeler){
        this.ID = ID;
        this.datum = datum;
        this.locatie = locatie;
        this.begintijd = begintijd;
        this.eindtijd = eindtijd;
        this.kosten = kosten;
        this.minRating = minRating;
        this.bekendePokerspeler = bekendePokerspeler;
    }

    public int getID() {
        return ID;
    }

    public String getDatum() {
        return datum;
    }

    public String getLocatie() {
        return locatie;
    }

    public String getBegintijd() {
        return begintijd;
    }

    public String getEindtijd() {
        return eindtijd;
    }

    int getKosten() {
        return kosten;
    }

    int getMinRating() {
        return minRating;
    }

    String getBekendePokerspeler() {
        return bekendePokerspeler;
    }

    public String toString(){
        return "ID: " + ID + " DATUM: " + datum + " LOCATIE: " + locatie + " BEGINTIJD: " + begintijd + " EINDTIJD: " + eindtijd + " KOSTEN € " + kosten + " MIN RATING: " + minRating + " BEKENDE POKERSPELER: " + bekendePokerspeler;
    }
}
