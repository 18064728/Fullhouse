import javax.swing.*;
import java.sql.*;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;

/**
 * Medewerker krijgt aparte panel van alle bekende pokerspelers en heeft de mogelijkheid om ze te bewerken of te verwijderen
 */

class BekendePokerspelerControleren extends JDialog {

    //JDIALOG
    private static final int width = 750;
    private static final int height = 500;
    private static final String title = "Bekende pokerspeler controleren";

    //ATTRIBUTES
    private String naam;

    private DefaultListModel<BekendePokerspeler> model;
    private JList<BekendePokerspeler> pokerspelers;

    private JButton bewerkBtn;
    private JButton terugBtn;
    private JButton verwijderBtn;

    BekendePokerspelerControleren()  {

        JPanel panel = new JPanel();
        panel.setLayout(null);

        try { //tries to make a connection with the database
            ResultSet rs = ConnectionManager.getConnection().createStatement().executeQuery("SELECT * FROM bekende_pokerspeler");

            model = new DefaultListModel<>();
            pokerspelers = new JList<>(model);
            panel.add(pokerspelers);
            JScrollPane sp = new JScrollPane(pokerspelers);
            sp.setBounds(125,25,500,400);
            panel.add(sp);

            while (rs.next()) {
                naam = rs.getString("naam");

                BekendePokerspeler bp = new BekendePokerspeler(naam);
                model.addElement(bp);
            }

        } catch (SQLException e) { //error message if there's no connection with the database
            e.printStackTrace();
        }

        this.setSize(width, height);
        this.setTitle(title);
        this.setDefaultCloseOperation(DISPOSE_ON_CLOSE);
        this.setVisible(true);

        if (model.isEmpty()) {
            JOptionPane.showMessageDialog(null, "er zijn nog geen bekende pokerspelers toegevoegd, voeg ze toe vie 'bekende pokerspeler toevoegen'");
        }
        else {
            bewerkBtn = new JButton("Bewerken");
            terugBtn = new JButton("Terug");
            verwijderBtn = new JButton("Verwijder");

            bewerkBtn.setBounds(0, 0, 100, 30);
            terugBtn.setBounds(0, 55, 100, 30);
            verwijderBtn.setBounds(0, 110, 100, 30);

            panel.add(bewerkBtn);
            panel.add(terugBtn);
            panel.add(verwijderBtn);

            ActionListener terug = new Terug();
            ActionListener verwijder = new Verwijder(pokerspelers);
            ActionListener bewerk = new Bewerk(pokerspelers);

            bewerkBtn.addActionListener(bewerk);
            terugBtn.addActionListener(terug);
            verwijderBtn.addActionListener(verwijder);

            this.add(panel);
        }
    }

    class Terug implements ActionListener {
        @Override
        public void actionPerformed(ActionEvent e) {
            dispose();
        }
    }

    class Bewerk implements ActionListener {
        private JList<BekendePokerspeler> list;

        private Bewerk(JList<BekendePokerspeler> list) {
            this.list = list;
        }

        @Override
        public void actionPerformed(ActionEvent e) {
            try {
                if (list.isSelectionEmpty()) {
                    JOptionPane.showMessageDialog(null, "Kies een bekende pokerspeler om te bewerken");
                }
                else {
                    class BekendePokerspelerBewerken extends BekendePokerspelerToevoegen {

                        private BekendePokerspelerBewerken() {
                            naamBekendTxt.setText(list.getSelectedValue().getNaam());
                        }

                        class Terug implements ActionListener {
                            public void actionPerformed(ActionEvent e) {
                                dispose();
                            }
                        }
                    }
                    JDialog d = new BekendePokerspelerBewerken();
                    d.setSize(500, 500);
                    d.setTitle("Gast bewerken");
                    d.setResizable(false);
                    d.setVisible(true);
                    d.setDefaultCloseOperation(DISPOSE_ON_CLOSE);
                }
            } catch (Exception e1) {
                e1.printStackTrace();
            }
        }
    }

    class Verwijder implements ActionListener {
        private JList<BekendePokerspeler> list;
        private Verwijder(JList<BekendePokerspeler> list) {
            this.list = list;
        }

        @Override
        public void actionPerformed(ActionEvent e) {
            try {
                if (list.isSelectionEmpty()) {
                    JOptionPane.showMessageDialog(null,"Kies een bekende pokerspeler om te verwijderen");
                }
                else {
                    String naam = list.getSelectedValue().getNaam();
                    PreparedStatement ps = ConnectionManager.getConnection().prepareStatement("DELETE FROM bekende_pokerspeler WHERE naam = ?");
                    ps.setString(1,naam);
                    ps.executeUpdate();
                    model.removeElement(list.getSelectedValue());
                }
            } catch (SQLException e1){
                e1.printStackTrace();
            }
        }
    }
}