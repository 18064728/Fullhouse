package fullhouse;

import java.sql.Date;

public class Gast {

    private String naam;
    private String geslacht;
    private Date geboortedatum;
    private String adres;
    private String postcode;
    private String woonplaats;
    private String telefoonnummer;
    private String email;

    public Gast(String naam, String geslacht, Date geboortedatum, String adres, String postcode, String woonplaats, String telefoonnummer, String email) {

       this.naam = naam;
       this.geslacht = geslacht;
       this.geboortedatum = geboortedatum;
       this.adres = adres;
       this.postcode = postcode;
       this.woonplaats = woonplaats;
       this.telefoonnummer = telefoonnummer;
       this.email = email;
    }

    public void nextID() {
    }

    public String toString() {
        return  naam + " " + geslacht + " " + geboortedatum + " " + adres + " " + postcode + " " + woonplaats + " " + telefoonnummer + " " + email ;
    }
}