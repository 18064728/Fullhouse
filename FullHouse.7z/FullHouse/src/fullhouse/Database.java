package fullhouse;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.ResultSet;
import java.util.Scanner;

public class Database {

    public static void main(String[] args) {
        try {
            Connection connection = DriverManager.getConnection(
                    "jdbc:mysql://localhost/fullhouse?useLegacyDatetimeCode=false&serverTimezone=Europe/Amsterdam", "root", "kamikaze");
            System.out.println("connected to database");

            Scanner scanner = new Scanner(System.in);
            String attribute = scanner.next();
            ResultSet resultSet = connection.createStatement().executeQuery("SELECT " + attribute + " from gast");
            //connection.createStatement().executeUpdate("INSERT INTO book (author, title) VALUES ('Joost Simons', 'beste boek ooit')");

            while (resultSet.next()) {
                //System.out.print(resultSet.getString("*"));
                //System.out.format("%s, %s, %s, %s, %s, %s\n", "ID", "Naam", "Geslacht", "geboortedatum", "adres", "postcode");
                System.out.print(resultSet.getString("Naam"));
                //System.out.print(resultSet.getString("author"));
               // System.out.print(" ");
               // System.out.print(resultSet.getString("title"));
               // System.out.println();
            }

        } catch (Exception e) {
            //System.out.println("could not connect to database");
            e.printStackTrace();
        }
    }
}
