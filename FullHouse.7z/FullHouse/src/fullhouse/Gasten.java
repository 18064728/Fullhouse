package fullhouse;

import javax.swing.*;
import java.awt.*;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;

public class Gasten extends JDialog {

    private static final int width = 300;
    private static final int height = 400;
    private static final String title = "gasten";

    public static void main(String[] args) {
        Gasten g = new Gasten();
    }

    public Gasten() {
        addComponents();
        setSize(width, height);
        setTitle(title);
        setDefaultCloseOperation(DISPOSE_ON_CLOSE);
        setVisible(true);
    }

    public void addComponents() {
        JPanel panel = new JPanel();
        panel.setLayout(new BoxLayout(panel, BoxLayout.PAGE_AXIS));

        JButton toevoegenBtn = new JButton("toevoegen");
        JButton controlerenBtn = new JButton("controleren");
        JButton verwijderenBtn = new JButton("verwijderen");
        JButton terubgBtn = new JButton("terug");

        Dimension minSize = new Dimension(100, 50);
        Dimension prefSize = new Dimension(100, 50);
        Dimension maxSize = new Dimension(Short.MAX_VALUE, 50);

        panel.add(new Box.Filler(minSize, prefSize, maxSize));
        panel.add(toevoegenBtn);
        panel.add(new Box.Filler(minSize, prefSize, maxSize));
        panel.add(controlerenBtn);
        panel.add(new Box.Filler(minSize, prefSize, maxSize));
        panel.add(verwijderenBtn);
        panel.add(new Box.Filler(minSize, prefSize, maxSize));
        panel.add(terubgBtn);

        class Toevoegen implements ActionListener {
            public void actionPerformed(ActionEvent e) {
                JDialog d = new Gast_Toevoegen();
                d.setVisible(true);
                d.setSize(500,500);
                System.out.println("gast toevoegen");
                dispose();
            }
        }

        class Controleren implements ActionListener {
            public void actionPerformed(ActionEvent e) {
                JDialog d = new Gast_Controleren();
                d.setVisible(true);
                d.setSize(1200,500);
                System.out.println("gast controleren");
                dispose();
            }
        }

        class Verwijderen implements ActionListener {
            public void actionPerformed(ActionEvent e) {
                //hide();
                System.out.println("gast verwijderen");
            }
        }

        class Terug implements ActionListener {
            public void actionPerformed(ActionEvent e) {
                new FullHouse();
                dispose();
            }
        }

        ActionListener terug = new Terug();
        ActionListener toevoegen = new Toevoegen();
        ActionListener controleren = new Controleren();
        ActionListener verwijderen = new Verwijderen();

        terubgBtn.addActionListener(terug);
        toevoegenBtn.addActionListener(toevoegen);
        controlerenBtn.addActionListener(controleren);
        verwijderenBtn.addActionListener(verwijderen);

        add(panel);
    }
}