package fullhouse;

import javax.swing.*;
import java.awt.*;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;

public class Masterclass extends JDialog {

    private static final int width = 300;
    private static final int height = 400;
    private static final String title = "masterclass";

    public static void main(String[] args) {
        Masterclass m = new Masterclass();
    }

    public Masterclass() {
        addComponents();
        setSize(width, height);
        setTitle(title);
        setDefaultCloseOperation(DISPOSE_ON_CLOSE);
        setVisible(true);
    }

    public void addComponents() {
        JPanel panel = new JPanel();
        panel.setLayout(new BoxLayout(panel, BoxLayout.PAGE_AXIS));

        JButton toevoegenBtn = new JButton("toevoegen");
        JButton controlerenBtn = new JButton("controleren");
        JButton verwijderenBtn = new JButton("verwijderen");
        JButton terugBtn = new JButton("terug");

        Dimension minSize = new Dimension(100, 50);
        Dimension prefSize = new Dimension(100, 50);
        Dimension maxSize = new Dimension(Short.MAX_VALUE, 50);

        panel.add(new Box.Filler(minSize, prefSize, maxSize));
        panel.add(toevoegenBtn);
        panel.add(new Box.Filler(minSize, prefSize, maxSize));
        panel.add(controlerenBtn);
        panel.add(new Box.Filler(minSize, prefSize, maxSize));
        panel.add(verwijderenBtn);
        panel.add(new Box.Filler(minSize, prefSize, maxSize));
        panel.add(terugBtn);

        class Terug implements ActionListener {
            public void actionPerformed(ActionEvent e) {
                new FullHouse();
                dispose();
            }
        }
        ActionListener terug = new Terug();
        terugBtn.addActionListener(terug);

        add(panel);
    }
}