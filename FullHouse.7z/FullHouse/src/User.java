import java.text.DecimalFormat;
import java.text.ParseException;
import java.util.Date;
import java.text.SimpleDateFormat;

public class User {

    private String name;
    private double value;
    private Date date;

    public User(String name, String value, String date) {
        try {
            SimpleDateFormat formatter = new SimpleDateFormat("dd-MM-yyyy");
            DecimalFormat df = new DecimalFormat("#.##");
            double number = Double.parseDouble(value);

            this.name = name;
            this.value = number;
            this.date = formatter.parse(date);

        } catch (ParseException e) {
            System.out.println("date is invalid");
        }
    }

    public String getDate() {
        switch(date.getDay()) {
            case 0:
                return "monday";
            case 1:
                return "tuesday";
            case 2:
                return "wednesday";
            case 3:
                return "thursday";
            case 4:
                return "friday";
            case 5:
                return  "saturday";
            case 6:
                return  "sunday";
                default: return null;
        }
    }

    public String toString() {
        return "name: " + name + "\nvalue: " + value + "\ndate: " + getDate() + "\n";
    }
}