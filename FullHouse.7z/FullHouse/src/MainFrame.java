import javax.swing.*;
import java.awt.*;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;

public class MainFrame extends JFrame {

    private static final int width = 300;
    private static final int height = 400;
    private static final String title = "Factuur toevoegen";

    public static void main(String[] args) {
        JFrame f = new MainFrame();
        f.setSize(width, height);
        f.setTitle(title);
        f.setDefaultCloseOperation(EXIT_ON_CLOSE);
        f.setVisible(true);
    }

    public MainFrame() {
        addComponents();
    }

    public void addComponents() {
        JPanel panel = new JPanel();
        panel.setLayout(new GridLayout(2,1, 300, 50));

        JPanel upperPanel = new JPanel();
        upperPanel.setLayout(new GridLayout(1,2));

        JPanel inputPanel = new JPanel();
        inputPanel.setLayout(new GridLayout(4,2));
        JLabel label1 = new JLabel("Invoice number");
        JLabel label2 = new JLabel("Customer number");
        JLabel label3 = new JLabel("bedrag");
        JLabel label4 = new JLabel("datum");

        JTextField txt1 = new JTextField();
        txt1.setSize(20,10);
        JTextField txt2 = new JTextField();
        txt2.setSize(new Dimension(100,20));
        JTextField txt3 = new JTextField();
        txt3.setSize(new Dimension(100,20));
        JTextField txt4 = new JTextField();
        txt4.setSize(new Dimension(100,20));

        inputPanel.add(label1);
        inputPanel.add(txt1);
        inputPanel.add(label2);
        inputPanel.add(txt2);
        inputPanel.add(label3);
        inputPanel.add(txt3);
        inputPanel.add(label4);
        inputPanel.add(txt4);

        JPanel searchPanel = new JPanel();
        JButton zoek = new JButton("zoek");
        searchPanel.add(zoek);

        JPanel underPanel = new JPanel();
        JButton save = new JButton("opslaan");
        underPanel.add(save);

        class Listener implements ActionListener {
            public void actionPerformed(ActionEvent e) {
                JDialog D1 = new Dialog1();
            }
        }

        Listener listener = new Listener();
        zoek.addActionListener(listener);
        upperPanel.add(inputPanel);
        upperPanel.add(searchPanel);
        panel.add(upperPanel);
        panel.add(underPanel);
        add(panel);
    }
}