import javax.swing.*;
import java.awt.*;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;

public class Dialog1 extends javax.swing.JDialog {

    private static final int width = 300;
    private static final int height = 400;
    private static final String title = "Klant zoeken";

    public static void main(String[] args) {
        Dialog1 j = new Dialog1();
    }

    public Dialog1() {
        addComponents();
        setSize(width, height);
        setTitle(title);
        setDefaultCloseOperation(DISPOSE_ON_CLOSE);
        setVisible(true);
    }

    public void addComponents() {
        JPanel inputPanel = new JPanel();
        JTextField input = new JTextField();
        input.setPreferredSize(new Dimension(100,20));
        JButton zoek = new JButton("zoek");
        inputPanel.add(input);
        inputPanel.add(zoek);

        JPanel selectionPanel = new JPanel();
        selectionPanel.setLayout(new GridLayout(3,1));
        JRadioButton rb1 = new JRadioButton("Op naam");
        JRadioButton rb2 = new JRadioButton("Op plaats");
        JRadioButton rb3 = new JRadioButton("Op postcode");
        ButtonGroup bg = new ButtonGroup();
        bg.add(rb1);
        bg.add(rb2);
        bg.add(rb3);
        selectionPanel.add(rb1);
        selectionPanel.add(rb2);
        selectionPanel.add(rb3);

        //todo add boxlayout
        JPanel outputPanel = new JPanel();
        JLabel label = new JLabel("Zoekresultaat");
        JTextField output = new JTextField();
        output.setPreferredSize(new Dimension(100,200));
        JButton ok = new JButton("Ok");
        outputPanel.add(label);
        outputPanel.add(output);
        outputPanel.add(ok);

        class zoekListener implements ActionListener {
            public void actionPerformed(ActionEvent e) {
                System.out.println("hi");
            }
        }

        class okListener implements ActionListener {
            public void actionPerformed(ActionEvent e) {
                dispose();
            }
        }

        ActionListener Zoek = new zoekListener();
        ActionListener Ok = new okListener();
        zoek.addActionListener(Zoek);
        ok.addActionListener(Ok);

        JPanel panel = new JPanel();
        panel.setLayout(new GridLayout(3,1));
        panel.add(inputPanel);
        panel.add(selectionPanel);
        panel.add(outputPanel);
        add(panel);
    }
}