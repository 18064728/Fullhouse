import java.io.File;
import java.util.ArrayList;
import java.util.Scanner;

public class FileReader {
    public static void main(String [] args) {
        String name;
        String value;
        String date;
        ArrayList<User> users ;

        try {
            File bestand = new File("C:\\Users\\Joost\\IdeaProjects\\fullhouse\\input.txt");
            Scanner in = new Scanner(bestand);
            users = new ArrayList<>();
            while (in.hasNextLine()) {
                    name = in.next();
                    value = in.next();
                    date = in.next();
                    User user = new User(name, value, date);
                    users.add(user);
            }

            System.out.println(users.get(1));

        } catch (Exception e) {
            System.out.println("can't open file");
        }
    }
}
